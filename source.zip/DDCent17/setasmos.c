
/*              Copyright 1993 Colorado State University                    */
/*                      All Rights Reserved                                 */

/*****************************************************************************
**
**  FILE:  setasmos.c
**
**  FUNCTION: void setasmos()
**
**  PURPOSE:  To set asmos, avh2o and rfwc (Century variables) from swc, the
**            soil water content in the daily soil water model
**
**  INPUTS:
**     nlayer  - number of layers in Century soil profile
**     numlyrs - total number of layers in the soil water model soil profile
**     swc[]   - soil water content by layer (cm H2O)
**
**  GLOBAL VARIABLES:
**    CMXLYR     - maximum number of Century soil layers (10)
**    MXSWLYR    - maximum number of soil water model layers (21)
**
**  EXTERNAL VARIABLES:
**    layers             - soil water soil layer structure
**    layers->fieldc[]   - volumetric water content at field capacity for
**                         layer (cm H2O/cm of soil)
**    layers->lbnd[]     - the index of the lower soil water model layer which
**                         corresponds to clyr in Century
**    layers->swclimit[] - minimum volumetric soil water content of a layer,
**                         fraction 0.0 - 1.0
**    layers->swcwp[]    - volumetric soil water content at wilting point for
**                         layer (cm H2O)
**    layers->ubnd[]     - the index of the upper soil water model layer which
**                         corresponds to layer clyr in Century
**    layers->width[]    - the thickness of soil water model layers (cm)
**
**  LOCAL VARIABLES:
**    clyr       - Century soil layer (1..nlayer)
**    ilyr       - current layer in the soil profile
**    tdepth     - total depth for Century soil layer
**
**  OUTPUTS:
**    asmos[] - soil water content by layer (cm H2O)
**    avh2o[] - water available for plant growth (avh2o[0]),
**                                  plant survival (avh2o[1]),
**               and in the first two Century soil layers (avh2o[2])
**    rwcf[]  - relative water content by layer
**
**  CHANGES:
**    KLK 5 May 2015  Make swc argument double so it can be called with swc array
**                    instead a float copy
**    KLK 8 Apr 2015  Refactored rwcf calculation to remove temporary array tmp_rwcf
**                    put avh2o[0] and avh2o[1] sums in same loop
**
**  CALLED BY:
**    detiv()
**    watflow()
**
**  CALLS:
**    None
**
*****************************************************************************/

#include "soilwater.h"

    void setasmos(float asmos[CMXLYR], int *nlayer, double swc[MXSWLYR],
                  int *numlyrs, float avh2o[3], float rwcf[CMXLYR])
    {
      int   ilyr;
      int   clyr;  /* index for "century" soil layers, 1..nlayer */
      float tdepth;

      extern LAYERPAR_SPT layers;

      /* Set asmos from swc*/

      for(clyr=0; clyr < *nlayer; clyr++) {
        asmos[clyr] = 0.0f;
        rwcf[clyr] = 0.0f;
        tdepth = 0.0f;
        for(ilyr = layers->ubnd[clyr]; ilyr <= layers->lbnd[clyr]; ilyr++) {
          asmos[clyr] += swc[ilyr];
/*        tmp_rwcf[ilyr] = (swc[ilyr]/(layers->width[ilyr]) - layers->swclimit[ilyr]) /
                           (layers->fieldc[ilyr] - layers->swclimit[ilyr]);

          printf("tmp_rwcf[%1d] = %5.2f  ", ilyr, tmp_rwcf[ilyr]);
          rwcf[clyr] += tmp_rwcf[ilyr]*layers->width[ilyr]; */

          rwcf[clyr] += (swc[ilyr] - layers->width[ilyr]*layers->swclimit[ilyr])
                       /(layers->fieldc[ilyr] - layers->swclimit[ilyr]);

          tdepth += layers->width[ilyr];
        }
        rwcf[clyr] /= tdepth;
/*        printf("\nrwcf[%1d] = %5.2f\n", clyr, rwcf[clyr]); */
        rwcf[clyr] = max(rwcf[clyr], 0.0f);
      }

      asmos[*nlayer] = swc[*numlyrs];
      rwcf[*nlayer] = 0.0f;

/*      printf("setasmos  asmos: ");
      for(ilyr=0; ilyr<= *nlayer; ilyr++)
        printf("%8.4f  ", asmos[ilyr]);
      printf("\n");
      printf("swc: ");
      for(ilyr=0; ilyr<= *numlyrs; ilyr++)
        printf("%8.4f  ", swc[ilyr]);
      printf("\n"); */

      /* Set avh2o */

      avh2o[0] = 0.0f;  /* avh2o(1): 0 to 30 cm */
      avh2o[1] = 0.0f;  /* avh2o(2): 1..nlayer */
      avh2o[2] = 0.0f;  /* avh2o(3): 1, 2 */

      /* assumes the depth at the bottom of numlyrs = the depth at nlayer */
      for(ilyr=0; ilyr <= layers->lbnd[*nlayer-1]; ilyr++) {
        if (swc[ilyr] - layers->swcwp[ilyr] > 0.0) {
          avh2o[1] +=  swc[ilyr] - layers->swcwp[ilyr];

          /* Water available for plant growth will be calculated down to a */
          /* 30 cm depth as this is the zone where the majority of roots */
          /* occur, cak - 02/05/2010 */
          if (layers->dpthmx[ilyr] <= 30.0) {
              avh2o[0] +=  swc[ilyr] - layers->swcwp[ilyr];
          }
        }
      }

      for(ilyr=0; ilyr <= layers->lbnd[2-1]; ilyr++) {
        if (swc[ilyr] - layers->swcwp[ilyr] > 0.0) {
          avh2o[2] +=  swc[ilyr] - layers->swcwp[ilyr];
        }
      }

      return;
    }
